# မြန်မာ Date — Android Demo APK

ဒီ project ဟာ ဖုန်းမှာ install လုပ်ပြီး UI ကို စမ်းကြည့်နိုင်ဖို့ အတွက် Offline Demo ဖြစ်ပါတယ်။

## ဒီ Demo မှာ စမ်းလို့ရတာ
- ပင်မစာမျက်နှာ
- Tab သုံးခု (ပင်မ၊ စကားပြော၊ အကောင့်)
- Demo ပို့စ်များ
- ပို့စ်အသစ်ကို ယာယီထည့်ပြခြင်း
- VIP၊ Video၊ Admin UI နမူနာ

## အရေးကြီး
ဒီ APK က တကယ့် online service မဟုတ်သေးပါ။ Login၊ online chat၊ cloud video upload၊ VIP payment၊ ads နဲ့ owner-only admin permission မပါသေးပါ။ ဒီ project ကို Firebase အပြည့်အဝချိတ်ထားတဲ့ project အဖြစ် မမှတ်ယူပါနဲ့။

## Android ဖုန်းတစ်လုံးတည်းနဲ့ APK build လုပ်နည်း
1. GitHub account ရှိပါက browser မှ `github.com` ကိုဝင်ပြီး repository အသစ်တစ်ခု ဖန်တီးပါ။ ဥပမာ `myanmar-date-demo`။ Public သို့မဟုတ် Private ကို ရွေးနိုင်ပါတယ်။
2. ဒီ ZIP ကို ဖြည်ပြီး ဖိုင်တွေကို repository ထဲ upload လုပ်ပါ။ `.github/workflows/build-apk.yml` ကိုလည်း ထည့်ရပါမယ်။ GitHub mobile browser မှာ ဖိုင်အများအပြား upload လုပ်ရခက်ပါက desktop mode သုံးပါ။
3. Repository ရဲ့ **Actions** tab ကို ဖွင့်ပါ။ ပထမအကြိမ်မှာ workflow အသုံးပြုခွင့်ကို Enable လုပ်ရန် လိုနိုင်ပါတယ်။
4. **Build Android Demo APK** workflow ကိုရွေးပြီး **Run workflow** ကိုနှိပ်ပါ။
5. Run ပြီးသွားလျှင် workflow run ထဲက **Artifacts** အောက်တွင် `myanmar-date-demo-apk` ကိုနှိပ်ပြီး ZIP artifact ကို download လုပ်ပါ။
6. Download လုပ်ထားတဲ့ artifact ZIP ကို ဖုန်းမှာ ဖြည်ပြီး `app-release.apk` ကိုဖွင့်ပါ။
7. Android က browser/file manager မှ install ခွင့်တောင်းလျှင် ကိုယ့် download app/browser အတွက် **Install unknown apps** ခ permission ကို түр зуур enable လုပ်ပါ။ APK ကို ယုံကြည်ရတဲ့ ကိုယ်ပိုင် repository build-ээс авсан эсэхийг шалгаад install လုပ်ပါ။ ပြီးနောက် အဲнэ permission ကို ပိတ်ထားပါ။

## Workflow မအောင်မြင်ရင်
- `Actions` tab ထဲက build log ကိုဖွင့်ပြီး error ကိုကြည့်ပါ။
- Repository root မှာ `pubspec.yaml`, `lib/main.dart`, `.github/workflows/build-apk.yml` ရှိကြောင်းစစ်ပါ။
- Flutter version / Android SDK ဆိုင်ရာ error ဖြစ်ပါက workflow ကို ပြန် run လုပ်ကြည့်ပါ။
