import 'package:flutter/material.dart';

void main() => runApp(const MyanmarDateDemo());

const burgundy = Color(0xFF6D1734);
const gold = Color(0xFFE2B86B);
const cream = Color(0xFFFFF8EF);

class MyanmarDateDemo extends StatelessWidget {
  const MyanmarDateDemo({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'မြန်မာ Date',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      colorScheme: ColorScheme.fromSeed(seedColor: burgundy),
      scaffoldBackgroundColor: cream,
      appBarTheme: const AppBarTheme(backgroundColor: burgundy, foregroundColor: Colors.white),
      useMaterial3: true,
    ),
    home: const DemoHome(),
  );
}

class DemoHome extends StatefulWidget {
  const DemoHome({super.key});
  @override
  State<DemoHome> createState() => _DemoHomeState();
}

class _DemoHomeState extends State<DemoHome> {
  int tab = 0;
  final List<Map<String, String>> posts = [
    {'name': 'မြန်မာ Date', 'text': 'မင်္ဂလာပါ။ မြန်မာ Date မှ ကြိုဆိုပါတယ်။ 🎉'},
    {'name': 'မိတ်ဆွေတစ်ဦး', 'text': 'ဒီနေ့ အားလုံးပျော်ရွှင်ကြပါစေ။ ❤️'},
  ];

  void addPost() {
    final controller = TextEditingController();
    showDialog(context: context, builder: (ctx) => AlertDialog(
      title: const Text('ပို့စ်အသစ်တင်မယ်'),
      content: TextField(controller: controller, maxLines: 4, decoration: const InputDecoration(hintText: 'ဘာတွေ မျှဝေချင်လဲ?', border: OutlineInputBorder())),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ပယ်ဖျက်')),
        FilledButton(onPressed: () {
          final value = controller.text.trim();
          if (value.isNotEmpty) setState(() => posts.insert(0, {'name': 'သင့်အကောင့်', 'text': value}));
          Navigator.pop(ctx);
        }, child: const Text('တင်မယ်')),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _feed(),
      _chat(),
      _profile(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('မြန်မာ Date', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [IconButton(onPressed: () => _notice('အသိပေးချက်စနစ်ကို နောက်အဆင့်တွင် ထည့်သွင်းပါမည်။'), icon: const Icon(Icons.notifications_outlined))]),
      body: pages[tab],
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(
        backgroundColor: burgundy, foregroundColor: Colors.white, onPressed: addPost,
        icon: const Icon(Icons.add), label: const Text('ပို့စ်တင်မယ်')) : null,
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'ပင်မ'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat), label: 'စကားပြော'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'အကောင့်'),
        ]),
    );
  }

  Widget _feed() => ListView(
    padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
    children: [
      Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: burgundy, borderRadius: BorderRadius.circular(18)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('မိတ်ဆွေသစ်တွေနဲ့ ဆုံတွေ့ပါ', style: TextStyle(color: gold, fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 6), Text('စကားပြောမယ် • မျှဝေမယ် • ပျော်ရွှင်မယ်', style: TextStyle(color: Colors.white)),
        ])),
      const SizedBox(height: 12),
      ...posts.map((post) => Card(margin: const EdgeInsets.only(bottom: 12), child: Padding(
        padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [const CircleAvatar(backgroundColor: burgundy, child: Icon(Icons.person, color: Colors.white)), const SizedBox(width: 10), Text(post['name']!, style: const TextStyle(fontWeight: FontWeight.bold))]),
          const SizedBox(height: 12), Text(post['text']!),
          const Divider(height: 24),
          Row(children: [
            IconButton(onPressed: () => _notice('Like ကို Demo အဖြစ်သာ ပြထားပါတယ်။'), icon: const Icon(Icons.favorite_border)),
            const Text('Like'), const SizedBox(width: 20),
            IconButton(onPressed: () => _notice('Comment စနစ်ကို နောက်အဆင့်တွင် ထည့်ပါမည်။'), icon: const Icon(Icons.chat_bubble_outline)),
            const Text('Comment'),
          ])
        ]))),
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('မှတ်ချက် — ဒီဗားရှင်းမှာ စမ်းသပ်ရန်အတွက်သာ ပို့စ်တွေကို ဖုန်းထဲတွင် ယာယီပြသထားပါတယ်။ အင်တာနက်ပေါ်သို့ မတင်ရသေးပါ။'))),
    ],
  );

  Widget _chat() => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
    const Icon(Icons.forum_rounded, size: 64, color: burgundy),
    const SizedBox(height: 12), const Text('Online စကားပြောစနစ်', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('ဒီ Demo မှာ Chat ပုံစံကိုသာ ပြထားပါတယ်။ တကယ့်အချိန်နှင့်တစ်ပြေးညီ စကားပြောနိုင်ရန် Server နဲ့ Database ချိတ်ဆက်ရပါမယ်။', textAlign: TextAlign.center),
    const SizedBox(height: 16), FilledButton(onPressed: () => _notice('Real-time Chat ကို နောက်အဆင့်တွင် တည်ဆောက်ပါမည်။'), child: const Text('Chat စနစ်အကြောင်း')),
  ])));

  Widget _profile() => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 16),
    const Center(child: CircleAvatar(radius: 42, backgroundColor: burgundy, child: Icon(Icons.person, color: gold, size: 48))),
    const SizedBox(height: 12), const Center(child: Text('Demo အသုံးပြုသူ', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
    const Center(child: Text('သရုပ်ပြအကောင့်')),
    const SizedBox(height: 20),
    Card(child: ListTile(leading: const Icon(Icons.workspace_premium, color: gold), title: const Text('VIP အဖွဲ့ဝင်'), subtitle: const Text('VIP ဝန်ဆောင်မှု — မချိတ်ဆက်ရသေးပါ'), trailing: const Icon(Icons.chevron_right), onTap: () => _notice('VIP ငွေပေးချေမှုကို နောက်အဆင့်တွင် ချိတ်ဆက်ပါမည်။'))),
    const Card(child: ListTile(leading: Icon(Icons.video_library_outlined), title: Text('ကျွန်ုပ်၏ Video များ'), subtitle: Text('Video Upload ကို နောက်အဆင့်တွင် ထည့်သွင်းပါမည်။'))),
    const Card(child: ListTile(leading: Icon(Icons.admin_panel_settings_outlined), title: Text('Admin Panel'), subtitle: Text('ပိုင်ရှင်အတည်ပြုစနစ် မချိတ်ဆက်ရသေးပါ။'))),
    const SizedBox(height: 12),
    const Text('ဒါက UI Demo ဖြစ်ပါတယ်။ Login၊ Cloud Chat၊ Video Upload၊ VIP Payment နဲ့ ကြော်ငြာတွေကို အမှန်တကယ် အလုပ်လုပ်စေရန် Backend ချိတ်ဆက်ရန် လိုအပ်ပါတယ်။', textAlign: TextAlign.center),
  ]);

  void _notice(String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}
